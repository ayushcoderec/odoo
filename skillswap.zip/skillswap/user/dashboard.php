<?php
session_start();
require_once '../config/db.php';

// Redirect unauthenticated users
if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Skill Swap</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Welcome, <?= htmlspecialchars($user['name']) ?> 👋</h2>
    
    <p><strong>Visibility:</strong> <?= $user['is_public'] ? 'Public' : 'Private' ?></p>
    <p><strong>Availability:</strong> <?= $user['availability'] ?: 'Not set' ?></p>

    <div class="mb-3">
        <a href="edit_profile.php" class="btn btn-outline-primary">Edit Profile</a>
        <a href="manage_skills.php" class="btn btn-outline-secondary">Manage Skills</a>
        <a href="my_swaps.php" class="btn btn-outline-success">View Swaps</a>
        <a href="browse_users.php" class="btn btn-outline-dark">Browse Users</a>
        <a href="../auth/logout.php" class="btn btn-danger">Logout</a>
    </div>
</body>
</html>
