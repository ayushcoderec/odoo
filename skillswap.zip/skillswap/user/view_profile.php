<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$current_user_id = $_SESSION['user_id'];
$target_user_id = $_GET['id'] ?? null;

if (!$target_user_id || !is_numeric($target_user_id)) {
    header('Location: browse_users.php');
    exit();
}

// Fetch user profile
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? AND is_public = 1 AND status = 'active'");
$stmt->execute([$target_user_id]);
$profile = $stmt->fetch();

if (!$profile) {
    echo "<div class='container mt-5 alert alert-danger'>User not found or private.</div>";
    exit();
}

// Fetch skills
$offered = $pdo->prepare("SELECT skill_name FROM skills_offered WHERE user_id = ?");
$offered->execute([$target_user_id]);
$skills_offered = $offered->fetchAll(PDO::FETCH_COLUMN);

$wanted = $pdo->prepare("SELECT skill_name FROM skills_wanted WHERE user_id = ?");
$wanted->execute([$target_user_id]);
$skills_wanted = $wanted->fetchAll(PDO::FETCH_COLUMN);

// Handle swap request
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $current_user_id !== $target_user_id) {
    // Check for existing request
    $check = $pdo->prepare("SELECT id FROM swap_requests WHERE sender_id = ? AND receiver_id = ? AND status = 'pending'");
    $check->execute([$current_user_id, $target_user_id]);
    if ($check->fetch()) {
        $message = "<div class='alert alert-warning'>You already sent a swap request.</div>";
    } else {
        $stmt = $pdo->prepare("INSERT INTO swap_requests (sender_id, receiver_id) VALUES (?, ?)");
        if ($stmt->execute([$current_user_id, $target_user_id])) {
            $message = "<div class='alert alert-success'>Swap request sent successfully!</div>";
        } else {
            $message = "<div class='alert alert-danger'>Failed to send request.</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Profile</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2><?= htmlspecialchars($profile['name']) ?>'s Profile</h2>

    <?php if ($message): ?>
        <?= $message ?>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-4">
            <?php if ($profile['profile_photo']): ?>
                <img src="../assets/img/<?= $profile['profile_photo'] ?>" class="img-thumbnail" style="width:100%; max-height:300px;">
            <?php else: ?>
                <img src="../assets/img/default.png" class="img-thumbnail" style="width:100%; max-height:300px;">
            <?php endif; ?>
        </div>
        <div class="col-md-8">
            <p><strong>Location:</strong> <?= htmlspecialchars($profile['location']) ?: 'N/A' ?></p>
            <p><strong>Availability:</strong> <?= htmlspecialchars($profile['availability']) ?: 'N/A' ?></p>

            <h5>Skills Offered</h5>
            <ul><?php foreach ($skills_offered as $skill) echo "<li>" . htmlspecialchars($skill) . "</li>"; ?></ul>

            <h5>Skills Wanted</h5>
            <ul><?php foreach ($skills_wanted as $skill) echo "<li>" . htmlspecialchars($skill) . "</li>"; ?></ul>

            <?php if ($current_user_id !== (int)$target_user_id): ?>
                <form method="POST">
                    <button class="btn btn-success mt-3">Request Swap</button>
                </form>
            <?php else: ?>
                <div class="alert alert-info mt-3">This is your own profile.</div>
            <?php endif; ?>
        </div>
    </div>
<form method="POST" action="send_request.php?id=<?= $user['id'] ?>">
    <input type="text" name="skill_offered" placeholder="Your skill" required>
    <input type="text" name="skill_requested" placeholder="Skill you want" required>
    <button class="btn btn-primary">Request Swap</button>
</form>

    <a href="browse_users.php" class="btn btn-secondary mt-4">Back to Search</a>
</body>
</html>
