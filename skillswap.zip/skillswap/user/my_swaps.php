<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";

// Handle actions: accept/reject/cancel
if (isset($_GET['action']) && isset($_GET['id'])) {
    $swap_id = intval($_GET['id']);
    $action = $_GET['action'];

    if ($action === 'accept') {
        $stmt = $pdo->prepare("UPDATE swap_requests SET status='accepted' WHERE id=? AND receiver_id=?");
        $stmt->execute([$swap_id, $user_id]);
        $message = "<div class='alert alert-success'>Swap accepted.</div>";
    } elseif ($action === 'reject') {
        $stmt = $pdo->prepare("UPDATE swap_requests SET status='rejected' WHERE id=? AND receiver_id=?");
        $stmt->execute([$swap_id, $user_id]);
        $message = "<div class='alert alert-warning'>Swap rejected.</div>";
    } elseif ($action === 'cancel') {
        $stmt = $pdo->prepare("UPDATE swap_requests SET status='cancelled' WHERE id=? AND sender_id=? AND status='pending'");
        $stmt->execute([$swap_id, $user_id]);
        $message = "<div class='alert alert-info'>Swap cancelled.</div>";
    }
}

// Fetch all swaps where user is sender or receiver
$stmt = $pdo->prepare("
    SELECT sr.*, 
           s.name AS sender_name, r.name AS receiver_name
    FROM swap_requests sr
    JOIN users s ON sr.sender_id = s.id
    JOIN users r ON sr.receiver_id = r.id
    WHERE sr.sender_id = ? OR sr.receiver_id = ?
    ORDER BY sr.created_at DESC
");
$stmt->execute([$user_id, $user_id]);
$swaps = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>My Swaps</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>My Swap Requests</h2>

    <?= $message ?>

    <?php if (!$swaps): ?>
        <div class="alert alert-info">You have no swap activity yet.</div>
    <?php else: ?>
        <table class="table table-bordered mt-4">
            <thead class="table-light">
                <tr>
                    <th>Date</th>
                    <th>Sender</th>
                    <th>Receiver</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($swaps as $swap): ?>
                    <tr>
                        <td><?= date('d M Y', strtotime($swap['created_at'])) ?></td>
                        <td><?= htmlspecialchars($swap['sender_name']) ?></td>
                        <td><?= htmlspecialchars($swap['receiver_name']) ?></td>
                        <td><span class="badge bg-<?= 
                            $swap['status'] === 'pending' ? 'warning' :
                            ($swap['status'] === 'accepted' ? 'success' :
                            ($swap['status'] === 'rejected' ? 'danger' : 'secondary')) ?>">
                            <?= ucfirst($swap['status']) ?></span>
                        </td>
                        <td>
                            <?php if ($swap['status'] === 'pending'): ?>
                                <?php if ($swap['receiver_id'] == $user_id): ?>
                                    <a href="?action=accept&id=<?= $swap['id'] ?>" class="btn btn-sm btn-success">Accept</a>
                                    <a href="?action=reject&id=<?= $swap['id'] ?>" class="btn btn-sm btn-danger">Reject</a>
                                <?php elseif ($swap['sender_id'] == $user_id): ?>
                                    <a href="?action=cancel&id=<?= $swap['id'] ?>" class="btn btn-sm btn-secondary">Cancel</a>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-muted">No action</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <a href="dashboard.php" class="btn btn-secondary mt-4">Back to Dashboard</a>
</body>
</html>
