<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = "";

// Handle feedback submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $swap_id = intval($_POST['swap_id']);
    $rating = intval($_POST['rating']);
    $comment = trim($_POST['comment']);

    // Check if feedback already exists
    $check = $pdo->prepare("SELECT id FROM feedback WHERE swap_id = ? AND from_user_id = ?");
    $check->execute([$swap_id, $user_id]);

    if ($check->fetch()) {
        $errors[] = "You already left feedback for this swap.";
    } elseif ($rating < 1 || $rating > 5) {
        $errors[] = "Rating must be between 1 and 5.";
    } else {
        // Identify the other user
        $swap = $pdo->prepare("SELECT * FROM swap_requests WHERE id = ? AND status = 'accepted'");
        $swap->execute([$swap_id]);
        $data = $swap->fetch();

        if (!$data || ($data['sender_id'] != $user_id && $data['receiver_id'] != $user_id)) {
            $errors[] = "Invalid swap selection.";
        } else {
            $to_user_id = ($data['sender_id'] == $user_id) ? $data['receiver_id'] : $data['sender_id'];

            $stmt = $pdo->prepare("INSERT INTO feedback (swap_id, from_user_id, to_user_id, rating, comment) VALUES (?, ?, ?, ?, ?)");
            if ($stmt->execute([$swap_id, $user_id, $to_user_id, $rating, $comment])) {
                $success = "Feedback submitted successfully.";
            } else {
                $errors[] = "Failed to save feedback.";
            }
        }
    }
}

// Fetch completed swaps involving current user
$stmt = $pdo->prepare("
    SELECT sr.*, u.name as other_user
    FROM swap_requests sr
    JOIN users u ON (u.id = IF(sr.sender_id = ?, sr.receiver_id, sr.sender_id))
    WHERE (sr.sender_id = ? OR sr.receiver_id = ?) 
      AND sr.status = 'accepted'
      AND sr.id NOT IN (
          SELECT swap_id FROM feedback WHERE from_user_id = ?
      )
    ORDER BY sr.created_at DESC
");
$stmt->execute([$user_id, $user_id, $user_id, $user_id]);
$pending_feedback = $stmt->fetchAll();

// Fetch feedback history
$history = $pdo->prepare("
    SELECT f.*, u1.name as to_name, sr.created_at as swap_date
    FROM feedback f
    JOIN users u1 ON u1.id = f.to_user_id
    JOIN swap_requests sr ON sr.id = f.swap_id
    WHERE f.from_user_id = ?
    ORDER BY f.created_at DESC
");
$history->execute([$user_id]);
$feedback_given = $history->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Give Feedback</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Give Feedback</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php elseif ($errors): ?>
        <div class="alert alert-danger"><ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul></div>
    <?php endif; ?>

    <?php if ($pending_feedback): ?>
        <form method="POST" class="mb-4">
            <div class="mb-3">
                <label for="swap_id">Select Completed Swap</label>
                <select name="swap_id" class="form-select" required>
                    <?php foreach ($pending_feedback as $s): ?>
                        <option value="<?= $s['id'] ?>">With <?= htmlspecialchars($s['other_user']) ?> — <?= date('d M Y', strtotime($s['created_at'])) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Rating</label>
                <select name="rating" class="form-select" required>
                    <option value="">Choose...</option>
                    <?php for ($i = 5; $i >= 1; $i--): ?>
                        <option value="<?= $i ?>"><?= $i ?> Star<?= $i > 1 ? 's' : '' ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="mb-3">
                <label>Comment (optional)</label>
                <textarea name="comment" class="form-control" rows="3"></textarea>
            </div>

            <button type="submit" class="btn btn-primary">Submit Feedback</button>
        </form>
    <?php else: ?>
        <div class="alert alert-info">No swaps pending feedback.</div>
    <?php endif; ?>

    <h4 class="mt-5">Your Past Feedback</h4>
    <?php if ($feedback_given): ?>
        <table class="table table-bordered mt-2">
            <thead class="table-light">
                <tr>
                    <th>To</th>
                    <th>Swap Date</th>
                    <th>Rating</th>
                    <th>Comment</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($feedback_given as $f): ?>
                    <tr>
                        <td><?= htmlspecialchars($f['to_name']) ?></td>
                        <td><?= date('d M Y', strtotime($f['swap_date'])) ?></td>
                        <td><?= str_repeat('⭐', $f['rating']) ?></td>
                        <td><?= htmlspecialchars($f['comment']) ?: '<i>No comment</i>' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">You haven’t left any feedback yet.</p>
    <?php endif; ?>

    <a href="dashboard.php" class="btn btn-secondary mt-4">Back to Dashboard</a>
</body>
</html>
