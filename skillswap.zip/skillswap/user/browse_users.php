<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$search_term = $_GET['skill'] ?? '';
$results = [];

// Search logic
if ($search_term !== '') {
    $search_term = trim($search_term);
    $sql = "
        SELECT DISTINCT u.id, u.name, u.location, u.availability, u.profile_photo
        FROM users u
        LEFT JOIN skills_offered so ON u.id = so.user_id
        LEFT JOIN skills_wanted sw ON u.id = sw.user_id
        WHERE u.is_public = 1 AND u.status = 'active'
        AND (
            so.skill_name LIKE ? OR
            sw.skill_name LIKE ?
        )
        LIMIT 50
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(["%$search_term%", "%$search_term%"]);
    $results = $stmt->fetchAll();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Browse Users</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Search for Skill Swappers</h2>

    <form method="GET" class="mb-4 w-50">
        <div class="input-group">
            <input type="text" name="skill" class="form-control" placeholder="Search by skill..." value="<?= htmlspecialchars($search_term) ?>">
            <button class="btn btn-primary">Search</button>
        </div>
    </form>

    <?php if ($search_term && empty($results)): ?>
        <div class="alert alert-warning">No users found for "<strong><?= htmlspecialchars($search_term) ?></strong>".</div>
    <?php endif; ?>

    <div class="row">
        <?php foreach ($results as $user): ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100 shadow-sm">
                    <?php if ($user['profile_photo']): ?>
                        <img src="../assets/img/<?= $user['profile_photo'] ?>" class="card-img-top" style="max-height:200px; object-fit:cover;">
                    <?php else: ?>
                        <img src="../assets/img/default.png" class="card-img-top" style="max-height:200px; object-fit:cover;">
                    <?php endif; ?>
                    <div class="card-body">
                        <h5 class="card-title"><?= htmlspecialchars($user['name']) ?></h5>
                        <p class="card-text">
                            <strong>Location:</strong> <?= $user['location'] ?: 'N/A' ?><br>
                            <strong>Availability:</strong> <?= $user['availability'] ?: 'N/A' ?>
                        </p>
                        <a href="view_profile.php?id=<?= $user['id'] ?>" class="btn btn-outline-primary">View Profile</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <a href="dashboard.php" class="btn btn-secondary mt-4">Back to Dashboard</a>
</body>
</html>
