<?php
session_start();
require_once '../config/db.php';
require_once '../config/functions.php';

checkLogin(); // Ensure user is logged in

$receiver_id = intval($_GET['id'] ?? 0);
$offered = sanitize($_POST['skill_offered'] ?? '');
$requested = sanitize($_POST['skill_requested'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $receiver_id && $offered && $requested) {
    $stmt = $pdo->prepare("INSERT INTO swap_requests (sender_id, receiver_id, skill_offered, skill_requested) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_SESSION['user_id'], $receiver_id, $offered, $requested]);

    logAction($pdo, $_SESSION['user_id'], 'Sent Swap Request', "To User ID: $receiver_id");

    $_SESSION['message'] = "Swap request sent successfully!";
    header("Location: browse_users.php");
    exit();
}

// fallback: maybe invalid form
header("Location: view_profile.php?id=$receiver_id");
exit();
?>
