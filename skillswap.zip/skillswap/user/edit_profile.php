<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = "";

$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $location = trim($_POST['location']);
    $availability = $_POST['availability'] ?? '';
    $is_public = isset($_POST['is_public']) ? 1 : 0;

    // Handle profile photo upload
    $profile_photo = $user['profile_photo'];
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === 0) {
        $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
        $filename = 'user_' . $user_id . '.' . $ext;
        $target = '../assets/img/' . $filename;

        if (in_array(strtolower($ext), ['jpg', 'jpeg', 'png'])) {
            move_uploaded_file($_FILES['photo']['tmp_name'], $target);
            $profile_photo = $filename;
        } else {
            $errors[] = "Invalid image format.";
        }
    }

    if (!$errors) {
        $stmt = $pdo->prepare("UPDATE users SET name=?, location=?, profile_photo=?, availability=?, is_public=? WHERE id=?");
        if ($stmt->execute([$name, $location, $profile_photo, $availability, $is_public, $user_id])) {
            $success = "Profile updated successfully.";
        } else {
            $errors[] = "Failed to update profile.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Edit Profile</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <div class="alert alert-danger"><ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data" class="w-50">
        <div class="mb-2">
            <label>Name</label>
            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required>
        </div>
        <div class="mb-2">
            <label>Location</label>
            <input type="text" name="location" class="form-control" value="<?= htmlspecialchars($user['location']) ?>">
        </div>
        <div class="mb-2">
            <label>Availability</label>
            <select name="availability" class="form-select">
                <option value="">Select...</option>
                <option value="Weekends" <?= $user['availability'] === 'Weekends' ? 'selected' : '' ?>>Weekends</option>
                <option value="Evenings" <?= $user['availability'] === 'Evenings' ? 'selected' : '' ?>>Evenings</option>
                <option value="Mornings" <?= $user['availability'] === 'Mornings' ? 'selected' : '' ?>>Mornings</option>
            </select>
        </div>
        <div class="mb-2">
            <label>Profile Photo</label>
            <input type="file" name="photo" class="form-control">
            <?php if ($user['profile_photo']): ?>
                <img src="../assets/img/<?= $user['profile_photo'] ?>" width="100" class="mt-2">
            <?php endif; ?>
        </div>
        <div class="form-check mb-3">
            <input type="checkbox" name="is_public" class="form-check-input" id="public" <?= $user['is_public'] ? 'checked' : '' ?>>
            <label class="form-check-label" for="public">Make profile public</label>
        </div>
        <button class="btn btn-primary">Save Changes</button>
        <a href="dashboard.php" class="btn btn-secondary">Back</a>
    </form>
</body>
</html>
