<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../auth/login.php');
    exit();
}

$user_id = $_SESSION['user_id'];
$errors = [];
$success = "";

// Add Skill
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'];
    $skill = trim($_POST['skill']);

    if ($skill === '') {
        $errors[] = "Skill cannot be empty.";
    } else {
        if ($type === 'offered') {
            $stmt = $pdo->prepare("INSERT INTO skills_offered (user_id, skill_name) VALUES (?, ?)");
        } elseif ($type === 'wanted') {
            $stmt = $pdo->prepare("INSERT INTO skills_wanted (user_id, skill_name) VALUES (?, ?)");
        }

        if ($stmt->execute([$user_id, $skill])) {
            $success = "Skill added successfully.";
        } else {
            $errors[] = "Failed to add skill.";
        }
    }
}

// Delete Skill
if (isset($_GET['delete']) && isset($_GET['type'])) {
    $skill_id = intval($_GET['delete']);
    $type = $_GET['type'];

    if ($type === 'offered') {
        $stmt = $pdo->prepare("DELETE FROM skills_offered WHERE id = ? AND user_id = ?");
    } else {
        $stmt = $pdo->prepare("DELETE FROM skills_wanted WHERE id = ? AND user_id = ?");
    }

    $stmt->execute([$skill_id, $user_id]);
    header('Location: manage_skills.php');
    exit();
}

// Fetch Skills
$offered = $pdo->prepare("SELECT * FROM skills_offered WHERE user_id = ?");
$offered->execute([$user_id]);
$skills_offered = $offered->fetchAll();

$wanted = $pdo->prepare("SELECT * FROM skills_wanted WHERE user_id = ?");
$wanted->execute([$user_id]);
$skills_wanted = $wanted->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Skills</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Manage Your Skills</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php endif; ?>
    <?php if ($errors): ?>
        <div class="alert alert-danger"><ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul></div>
    <?php endif; ?>

    <form method="POST" class="mb-4 w-50">
        <label>Add a New Skill</label>
        <div class="input-group">
            <input type="text" name="skill" class="form-control" placeholder="e.g., Photoshop, Excel">
            <select name="type" class="form-select">
                <option value="offered">Offered</option>
                <option value="wanted">Wanted</option>
            </select>
            <button type="submit" class="btn btn-primary">Add</button>
        </div>
    </form>

    <div class="row">
        <div class="col-md-6">
            <h4>Skills Offered</h4>
            <ul class="list-group">
                <?php foreach ($skills_offered as $skill): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?= htmlspecialchars($skill['skill_name']) ?>
                        <a href="?delete=<?= $skill['id'] ?>&type=offered" class="btn btn-sm btn-danger">Delete</a>
                    </li>
                <?php endforeach; ?>
                <?php if (empty($skills_offered)): ?>
                    <li class="list-group-item text-muted">No skills added.</li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="col-md-6">
            <h4>Skills Wanted</h4>
            <ul class="list-group">
                <?php foreach ($skills_wanted as $skill): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?= htmlspecialchars($skill['skill_name']) ?>
                        <a href="?delete=<?= $skill['id'] ?>&type=wanted" class="btn btn-sm btn-danger">Delete</a>
                    </li>
                <?php endforeach; ?>
                <?php if (empty($skills_wanted)): ?>
                    <li class="list-group-item text-muted">No skills added.</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>

    <a href="dashboard.php" class="btn btn-secondary mt-4">Back to Dashboard</a>
</body>
</html>
