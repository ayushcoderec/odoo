<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

$filter = $_GET['status'] ?? 'all';

$query = "
    SELECT sr.*, s.name AS sender, r.name AS receiver
    FROM swap_requests sr
    JOIN users s ON sr.sender_id = s.id
    JOIN users r ON sr.receiver_id = r.id
";
if ($filter !== 'all') {
    $query .= " WHERE sr.status = " . $pdo->quote($filter);
}
$query .= " ORDER BY sr.created_at DESC";

$stmt = $pdo->query($query);
$swaps = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Swaps</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>All Swap Requests</h2>

    <div class="mb-3">
        <a href="?status=all" class="btn btn-outline-secondary <?= $filter === 'all' ? 'active' : '' ?>">All</a>
        <a href="?status=pending" class="btn btn-outline-warning <?= $filter === 'pending' ? 'active' : '' ?>">Pending</a>
        <a href="?status=accepted" class="btn btn-outline-success <?= $filter === 'accepted' ? 'active' : '' ?>">Accepted</a>
        <a href="?status=rejected" class="btn btn-outline-danger <?= $filter === 'rejected' ? 'active' : '' ?>">Rejected</a>
        <a href="?status=cancelled" class="btn btn-outline-dark <?= $filter === 'cancelled' ? 'active' : '' ?>">Cancelled</a>
    </div>

    <?php if ($swaps): ?>
        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>Date</th>
                    <th>Sender</th>
                    <th>Receiver</th>
                    <th>Skill Offered</th>
                    <th>Skill Requested</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($swaps as $s): ?>
                    <tr>
                        <td><?= date('d M Y, h:i A', strtotime($s['created_at'])) ?></td>
                        <td><?= htmlspecialchars($s['sender']) ?></td>
                        <td><?= htmlspecialchars($s['receiver']) ?></td>
                        <td><?= htmlspecialchars($s['skill_offered']) ?></td>
                        <td><?= htmlspecialchars($s['skill_requested']) ?></td>
                        <td>
                            <span class="badge bg-<?= 
                                $s['status'] === 'pending' ? 'warning' :
                                ($s['status'] === 'accepted' ? 'success' :
                                ($s['status'] === 'rejected' ? 'danger' : 'secondary')) ?>">
                                <?= ucfirst($s['status']) ?>
                            </span>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-info">No swap data found.</div>
    <?php endif; ?>

    <a href="dashboard.php" class="btn btn-secondary mt-4">Back to Dashboard</a>
</body>
</html>
