<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

$stmt = $pdo->query("
    SELECT f.*, 
           u1.name AS from_user, 
           u2.name AS to_user, 
           sr.created_at AS swap_date
    FROM feedback f
    JOIN users u1 ON f.from_user_id = u1.id
    JOIN users u2 ON f.to_user_id = u2.id
    JOIN swap_requests sr ON sr.id = f.swap_id
    ORDER BY f.created_at DESC
");
$feedbacks = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>All Feedback</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>User Feedback Summary</h2>

    <?php if ($feedbacks): ?>
        <table class="table table-bordered mt-4">
            <thead class="table-light">
                <tr>
                    <th>Date</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Swap Date</th>
                    <th>Rating</th>
                    <th>Comment</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($feedbacks as $f): ?>
                    <tr>
                        <td><?= date('d M Y, h:i A', strtotime($f['created_at'])) ?></td>
                        <td><?= htmlspecialchars($f['from_user']) ?></td>
                        <td><?= htmlspecialchars($f['to_user']) ?></td>
                        <td><?= date('d M Y', strtotime($f['swap_date'])) ?></td>
                        <td><?= str_repeat('⭐', $f['rating']) ?></td>
                        <td><?= htmlspecialchars($f['comment']) ?: '<i>No comment</i>' ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p class="text-muted">No feedback has been left yet.</p>
    <?php endif; ?>

    <a href="dashboard.php" class="btn btn-secondary mt-4">Back to Dashboard</a>
</body>
</html>
