<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Handle CSV export
function exportCSV($filename, $headers, $rows) {
    header('Content-Type: text/csv');
    header("Content-Disposition: attachment; filename=\"$filename\"");
    $out = fopen('php://output', 'w');
    fputcsv($out, $headers);
    foreach ($rows as $row) {
        fputcsv($out, $row);
    }
    fclose($out);
    exit();
}

if (isset($_GET['export'])) {
    $type = $_GET['export'];

    if ($type === 'logs') {
        $stmt = $pdo->query("SELECT l.id, u.name, l.action, l.description, l.timestamp 
                             FROM activity_logs l 
                             JOIN users u ON l.user_id = u.id 
                             ORDER BY l.timestamp DESC");
        $rows = $stmt->fetchAll(PDO::FETCH_NUM);
        exportCSV("activity_logs.csv", ['Log ID', 'User', 'Action', 'Description', 'Timestamp'], $rows);
    }

    if ($type === 'swaps') {
        $stmt = $pdo->query("SELECT s.id, u1.name AS sender, u2.name AS receiver, s.status, s.created_at 
                             FROM swap_requests s
                             JOIN users u1 ON s.sender_id = u1.id 
                             JOIN users u2 ON s.receiver_id = u2.id 
                             ORDER BY s.created_at DESC");
        $rows = $stmt->fetchAll(PDO::FETCH_NUM);
        exportCSV("swap_stats.csv", ['Swap ID', 'Sender', 'Receiver', 'Status', 'Created At'], $rows);
    }

    if ($type === 'feedback') {
        $stmt = $pdo->query("SELECT f.id, u1.name AS from_user, u2.name AS to_user, f.rating, f.comment, f.created_at 
                             FROM feedback f
                             JOIN users u1 ON f.from_user_id = u1.id
                             JOIN users u2 ON f.to_user_id = u2.id
                             ORDER BY f.created_at DESC");
        $rows = $stmt->fetchAll(PDO::FETCH_NUM);
        exportCSV("feedback_summary.csv", ['Feedback ID', 'From', 'To', 'Rating', 'Comment', 'Created At'], $rows);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Export Reports</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Download Reports</h2>

    <ul class="list-group mt-4">
        <li class="list-group-item d-flex justify-content-between">
            <span>User Activity Logs</span>
            <a href="?export=logs" class="btn btn-sm btn-outline-primary">Download CSV</a>
        </li>
        <li class="list-group-item d-flex justify-content-between">
            <span>Swap Statistics</span>
            <a href="?export=swaps" class="btn btn-sm btn-outline-primary">Download CSV</a>
        </li>
        <li class="list-group-item d-flex justify-content-between">
            <span>Feedback Summary</span>
            <a href="?export=feedback" class="btn btn-sm btn-outline-primary">Download CSV</a>
        </li>
    </ul>

    <a href="dashboard.php" class="btn btn-secondary mt-4">Back to Dashboard</a>
</body>
</html>
