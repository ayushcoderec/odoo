<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Handle delete
if (isset($_GET['delete']) && isset($_GET['type'])) {
    $skill_id = intval($_GET['delete']);
    $type = $_GET['type'];

    if ($type === 'offered') {
        $stmt = $pdo->prepare("DELETE FROM skills_offered WHERE id = ?");
    } else {
        $stmt = $pdo->prepare("DELETE FROM skills_wanted WHERE id = ?");
    }

    $stmt->execute([$skill_id]);
    header("Location: moderate_skills.php?filter=$type");
    exit();
}

// Filter by type
$filter = $_GET['filter'] ?? 'offered';

if ($filter === 'wanted') {
    $stmt = $pdo->query("
        SELECT sw.id, sw.skill_name, u.name, u.email
        FROM skills_wanted sw
        JOIN users u ON sw.user_id = u.id
        ORDER BY sw.id DESC
    ");
} else {
    $stmt = $pdo->query("
        SELECT so.id, so.skill_name, u.name, u.email
        FROM skills_offered so
        JOIN users u ON so.user_id = u.id
        ORDER BY so.id DESC
    ");
}
$skills = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Moderate Skills</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Moderate Skills</h2>

    <div class="mb-3">
        <a href="?filter=offered" class="btn btn-outline-primary <?= $filter === 'offered' ? 'active' : '' ?>">Skills Offered</a>
        <a href="?filter=wanted" class="btn btn-outline-secondary <?= $filter === 'wanted' ? 'active' : '' ?>">Skills Wanted</a>
    </div>

    <?php if ($skills): ?>
        <table class="table table-bordered">
            <thead class="table-light">
                <tr>
                    <th>ID</th>
                    <th>Skill</th>
                    <th>User Name</th>
                    <th>User Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($skills as $skill): ?>
                    <tr>
                        <td><?= $skill['id'] ?></td>
                        <td><?= htmlspecialchars($skill['skill_name']) ?></td>
                        <td><?= htmlspecialchars($skill['name']) ?></td>
                        <td><?= htmlspecialchars($skill['email']) ?></td>
                        <td>
                            <a href="?delete=<?= $skill['id'] ?>&type=<?= $filter ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this skill?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <div class="alert alert-info">No skills found.</div>
    <?php endif; ?>

    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
</body>
</html>
