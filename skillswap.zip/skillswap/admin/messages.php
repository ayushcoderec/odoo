<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

$errors = [];
$success = "";

// Handle message submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $message = trim($_POST['message']);

    if (strlen($title) < 3) {
        $errors[] = "Title must be at least 3 characters.";
    }
    if (strlen($message) < 5) {
        $errors[] = "Message must be at least 5 characters.";
    }

    if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO admin_messages (title, message) VALUES (?, ?)");
        if ($stmt->execute([$title, $message])) {
            $success = "Message broadcasted successfully.";
        } else {
            $errors[] = "Failed to broadcast message.";
        }
    }
}

// Fetch previous messages
$messages = $pdo->query("SELECT * FROM admin_messages ORDER BY created_at DESC")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Broadcast Messages</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Broadcast a Message</h2>

    <?php if ($success): ?>
        <div class="alert alert-success"><?= $success ?></div>
    <?php elseif ($errors): ?>
        <div class="alert alert-danger"><ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul></div>
    <?php endif; ?>

    <form method="POST" class="mb-5">
        <div class="mb-3">
            <label>Title</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Message</label>
            <textarea name="message" class="form-control" rows="4" required></textarea>
        </div>
        <button class="btn btn-primary">Send Message</button>
    </form>

    <h4>Message History</h4>
    <?php if ($messages): ?>
        <ul class="list-group">
            <?php foreach ($messages as $msg): ?>
                <li class="list-group-item">
                    <strong><?= htmlspecialchars($msg['title']) ?></strong>
                    <p><?= nl2br(htmlspecialchars($msg['message'])) ?></p>
                    <small class="text-muted">Sent on <?= date('d M Y, h:i A', strtotime($msg['created_at'])) ?></small>
                </li>
            <?php endforeach; ?>
        </ul>
    <?php else: ?>
        <p class="text-muted">No broadcast messages yet.</p>
    <?php endif; ?>

    <a href="dashboard.php" class="btn btn-secondary mt-4">Back to Dashboard</a>
</body>
</html>
