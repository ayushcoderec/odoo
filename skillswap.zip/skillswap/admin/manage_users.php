<?php
session_start();
require_once '../config/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../auth/login.php');
    exit();
}

// Ban/unban user
if (isset($_GET['action']) && isset($_GET['id'])) {
    $user_id = intval($_GET['id']);
    $action = $_GET['action'] === 'ban' ? 'banned' : 'active';
    $stmt = $pdo->prepare("UPDATE users SET status = ? WHERE id = ? AND role = 'user'");
    $stmt->execute([$action, $user_id]);
    header("Location: manage_users.php");
    exit();
}

// Filter
$filter = $_GET['filter'] ?? 'all';
$query = "SELECT * FROM users WHERE role = 'user'";
if ($filter === 'active') $query .= " AND status = 'active'";
elseif ($filter === 'banned') $query .= " AND status = 'banned'";

$users = $pdo->query($query)->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2>Manage Users</h2>

    <div class="mb-3">
        <a href="?filter=all" class="btn btn-outline-secondary <?= $filter === 'all' ? 'active' : '' ?>">All</a>
        <a href="?filter=active" class="btn btn-outline-success <?= $filter === 'active' ? 'active' : '' ?>">Active</a>
        <a href="?filter=banned" class="btn btn-outline-danger <?= $filter === 'banned' ? 'active' : '' ?>">Banned</a>
    </div>

    <table class="table table-bordered">
        <thead class="table-light">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Status</th>
                <th>Availability</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><?= $u['id'] ?></td>
                    <td><?= htmlspecialchars($u['name']) ?></td>
                    <td><?= htmlspecialchars($u['email']) ?></td>
                    <td>
                        <span class="badge bg-<?= $u['status'] === 'active' ? 'success' : 'danger' ?>">
                            <?= ucfirst($u['status']) ?>
                        </span>
                    </td>
                    <td><?= htmlspecialchars($u['availability']) ?></td>
                    <td>
                        <?php if ($u['status'] === 'active'): ?>
                            <a href="?action=ban&id=<?= $u['id'] ?>" class="btn btn-sm btn-danger">Ban</a>
                        <?php else: ?>
                            <a href="?action=unban&id=<?= $u['id'] ?>" class="btn btn-sm btn-success">Unban</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <a href="dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
</body>
</html>
