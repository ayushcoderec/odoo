<?php
// ✅ Log user activity
function logAction($pdo, $user_id, $action, $desc = '') {
    $stmt = $pdo->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, ?, ?)");
    $stmt->execute([$user_id, $action, $desc]);
}

// ✅ Sanitize input
function sanitize($data) {
    return htmlspecialchars(trim($data));
}

// ✅ Check login
function checkLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../auth/login.php");
        exit();
    }
}
?>
