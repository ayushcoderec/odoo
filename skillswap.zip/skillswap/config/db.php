<?php
// Skill Swap Platform Initialization
// File: /config/db.php

$host = 'sdb-59.hosting.stackcp.net';
$db   = 'skill_swap-353032332fa1';
$user = 'skill_swap-353032332fa1';
$pass = 'l9zaxnw7hh';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
