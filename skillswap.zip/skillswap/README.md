# Skill Swap Platform
This is a PHP and MySQL-based Skill Swap Platform.